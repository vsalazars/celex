export default function MaterialsSection() {
  return (
    <div>
      <h2 className="text-lg font-semibold">Materiales</h2>
      <p className="text-sm text-neutral-600">Carga y gestión de materiales didácticos.</p>
    </div>
  );
}
