export default function SettingsSection() {
  return (
    <div>
      <h2 className="text-lg font-semibold">Configuración</h2>
      <p className="text-sm text-neutral-600">Preferencias de la cuenta.</p>
    </div>
  );
}
