export default function EvaluationsSection() {
  return (
    <div>
      <h2 className="text-lg font-semibold">Evaluaciones</h2>
      <p className="text-sm text-neutral-600">Registro de evaluaciones y calificaciones.</p>
    </div>
  );
}
