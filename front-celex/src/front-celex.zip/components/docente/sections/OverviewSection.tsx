export default function OverviewSection() {
  return (
    <div>
      <h2 className="text-lg font-semibold">Resumen</h2>
      <p className="text-sm text-neutral-600">Vista general de tu actividad.</p>
    </div>
  );
}
