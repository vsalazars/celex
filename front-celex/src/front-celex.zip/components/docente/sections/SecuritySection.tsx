export default function SecuritySection() {
  return (
    <div>
      <h2 className="text-lg font-semibold">Seguridad</h2>
      <p className="text-sm text-neutral-600">Contraseña y sesiones activas.</p>
    </div>
  );
}
