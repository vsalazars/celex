// app/docente/dashboard/page.tsx
export default function DocenteDashboard() {
  return (
    <main className="p-6">
      <h1 className="text-2xl font-semibold">Dashboard Docente</h1>
      <p className="text-sm text-neutral-600">Bienvenido.</p>
    </main>
  );
}
