// --- Coordinadores ---
export type CoordItem = {
  id: number;
  first_name: string;
  last_name: string;
  email: string;
  curp: string;
  role: string;
  is_active?: boolean;
};

export type CoordResp = {
  items: CoordItem[];
  total: number;
  page: number;
  page_size: number;
  pages: number;
};

// --- Genérico de paginación (para reusar si tu backend lo usa en más endpoints) ---
export type Paginated<T> = {
  items: T[];
  total: number;
  page: number;
  page_size: number;
  pages: number;
};

// --- Docentes ---
export type TeacherStatus = "activo" | "invitado" | "suspendido";

export type Teacher = {
  id: string | number;
  first_name: string;
  last_name: string;
  email: string;
  curp: string;
  status: TeacherStatus;
  created_at?: string;
};

export type CreateTeacherInput = {
  first_name: string;
  last_name: string;
  email: string;
  curp: string;
};



// src/lib/types.ts
// ===== Ciclos =====

// 👇 Enum de idiomas (ajusta según los que ofrezca CELEX)
export type Idioma = "ingles" | "frances" | "aleman" | "italiano" | "japones" | "otros";

export type PeriodoDTO = { from: string; to: string };

export type CicloDTO = {
  id: number;
  codigo: string;
  idioma: Idioma;                     // 👈 NUEVO
  modalidad: "intensivo" | "sabatino" | "semestral";
  turno: "matutino" | "vespertino" | "mixto";
  inscripcion: PeriodoDTO;
  reinscripcion: PeriodoDTO;
  curso: PeriodoDTO;
  colocacion: PeriodoDTO;
  examenMT: string;    // YYYY-MM-DD
  examenFinal: string; // YYYY-MM-DD
  notas?: string | null;
};

export type CicloListResponse = {
  items: CicloDTO[];
  total: number;
  page: number;
  page_size: number;
  pages: number;
};

export type ListCiclosParams = {
  page?: number;
  page_size?: number;
  q?: string;
  idioma?: Idioma;                    // 👈 NUEVO filtro
  modalidad?: "intensivo" | "sabatino" | "semestral";
  turno?: "matutino" | "vespertino" | "mixto";
};

export type PeriodoInput = { from: string; to: string };

export type CreateCicloInput = {
  codigo: string;
  idioma: Idioma;                     // 👈 NUEVO
  modalidad: "intensivo" | "sabatino" | "semestral";
  turno: "matutino" | "vespertino" | "mixto";
  inscripcion: PeriodoInput;
  reinscripcion: PeriodoInput;
  curso: PeriodoInput;
  colocacion: PeriodoInput;
  examenMT: string;    // YYYY-MM-DD
  examenFinal: string; // YYYY-MM-DD
  notas?: string;
};

export type UpdateCicloInput = CreateCicloInput;
