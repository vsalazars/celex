"use client";

import { useEffect, useRef, useState } from "react";
import { useForm, Controller, useWatch } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  PlusCircle, Search, Filter, ChevronLeft, ChevronRight,
  MoreVertical, Pencil, Trash2, Users, GraduationCap, Clock3, CalendarDays, Building2
} from "lucide-react"; // 👈 agrega Building2 para aula
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";

import {
  Dialog, DialogContent, DialogHeader,
  DialogTitle, DialogDescription, DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";

import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";

import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { es } from "date-fns/locale";

import {
  AlertDialog, AlertDialogTrigger, AlertDialogContent,
  AlertDialogHeader, AlertDialogTitle, AlertDialogDescription,
  AlertDialogFooter, AlertDialogCancel, AlertDialogAction
} from "@/components/ui/alert-dialog";

import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent,
  DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";

import {
  listCiclos, createCiclo, updateCiclo, deleteCiclo
} from "@/lib/api";
import type {
  CicloDTO, CicloListResponse, ListCiclosParams
} from "@/lib/types";

// ======= Utils =======
type DateRange = { from?: Date; to?: Date };
const fmt = new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "short", year: "numeric" });
const fmtShort = new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "2-digit" });

const fmtRange = (r?: DateRange) =>
  r?.from && r?.to ? `${fmt.format(r.from)} — ${fmt.format(r.to)}`
  : r?.from ? `${fmt.format(r.from)} — …` : "Seleccionar periodo";

const dateToISO = (d?: Date) => (d ? new Date(d).toISOString().slice(0, 10) : undefined);
const rangeToISO = (r?: DateRange) =>
  r?.from && r?.to ? ({ from: dateToISO(r.from)!, to: dateToISO(r.to)! }) : undefined;

const isoToDate = (s?: string) => (s ? new Date(`${s}T00:00:00`) : undefined);
const rangeFromDTO = (r?: { from: string; to: string }): DateRange =>
  r ? ({ from: isoToDate(r.from), to: isoToDate(r.to) }) : {};

// Horas válidas (HH:MM) para selects
const buildHorasValidas = (desde = 6, hasta = 22, pasoMin = 30) => {
  const out: string[] = [];
  for (let h = desde; h <= hasta; h++) {
    for (let m = 0; m < 60; m += pasoMin) {
      const hh = String(h).padStart(2, "0");
      const mm = String(m).padStart(2, "0");
      out.push(`${hh}:${mm}`);
    }
  }
  return out;
};
const horasValidas = buildHorasValidas(6, 22, 30);

// Días disponibles
const DIAS_OPCIONES = [
  { key: "lunes", label: "Lun" },
  { key: "martes", label: "Mar" },
  { key: "miercoles", label: "Mié" },
  { key: "jueves", label: "Jue" },
  { key: "viernes", label: "Vie" },
  { key: "sabado", label: "Sáb" },
];

// ======= Zod Schema =======
const RangeSchema = z.object({
  from: z.date({ required_error: "Requerido" }),
  to: z.date({ required_error: "Requerido" }),
}).refine((r) => r.from <= r.to, { message: "La fecha inicial debe ser anterior o igual a la final", path: ["to"] });

const HoraSchema = z.string().regex(/^\d{2}:\d{2}$/, "Formato HH:MM");

const FormSchema = z.object({
  codigo: z.string().min(3, "Mínimo 3 caracteres"),
  idioma: z.enum(["ingles", "frances", "aleman", "italiano", "portugues"], { required_error: "Selecciona idioma" }),
  modalidad: z.enum(["intensivo", "sabatino", "semestral"], { required_error: "Selecciona modalidad" }),
  turno: z.enum(["matutino", "vespertino", "mixto"], { required_error: "Selecciona turno" }),
  nivel: z.enum(["A1", "A2", "B1", "B2", "C1", "C2"], { required_error: "Selecciona nivel" }),

  // 👇 NUEVOS CAMPOS
  modalidad_asistencia: z.enum(["presencial", "virtual"], { required_error: "Selecciona modalidad de asistencia" }),
  aula: z.string().optional(),

  cupo_total: z.coerce.number({ required_error: "Requerido" }).int("Debe ser entero").min(0, "No puede ser negativo"),

  // 👇 Horario
  dias: z.array(z.string()).min(1, "Selecciona al menos un día"),
  hora_inicio: HoraSchema,
  hora_fin: HoraSchema,

  inscripcion: RangeSchema,
  reinscripcion: RangeSchema,
  curso: RangeSchema,
  colocacion: RangeSchema,
  examenMT: z.date({ required_error: "Requerido" }),
  examenFinal: z.date({ required_error: "Requerido" }),
  notas: z.string().optional(),
}).refine(
  (v) => !v.hora_inicio || !v.hora_fin || v.hora_inicio <= v.hora_fin,
  { path: ["hora_fin"], message: "La hora fin debe ser posterior a la de inicio" }
).superRefine((v, ctx) => {
  // 👇 Validación: si es presencial, aula es obligatoria no vacía
  if (v.modalidad_asistencia === "presencial" && (!v.aula || !v.aula.trim())) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["aula"],
      message: "El aula es requerida cuando la modalidad de asistencia es presencial",
    });
  }
});

type FormType = z.infer<typeof FormSchema>;

// ======= EMPTY FORM para limpiar el modal =======
const EMPTY_FORM: FormType = {
  codigo: "",
  idioma: undefined as unknown as FormType["idioma"],
  modalidad: undefined as unknown as FormType["modalidad"],
  turno: undefined as unknown as FormType["turno"],
  nivel: undefined as unknown as FormType["nivel"],

  // 👇 NUEVOS DEFAULTS
  modalidad_asistencia: "presencial",
  aula: "",

  cupo_total: 0,

  dias: [],
  hora_inicio: "" as any,
  hora_fin: "" as any,

  inscripcion: {} as any,
  reinscripcion: {} as any,
  curso: {} as any,
  colocacion: {} as any,
  examenMT: undefined as any,
  examenFinal: undefined as any,
  notas: "",
};

// ======= Pickers =======
function DatePicker({
  label, value, onChange, placeholder = "Seleccionar fecha", error,
}: { label: string; value?: Date; onChange: (d?: Date) => void; placeholder?: string; error?: string; }) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <Label className="text-xs">{label}</Label>
        {error ? <span className="text-[11px] text-red-500">{error}</span> : null}
      </div>
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" className="w-full justify-start rounded-xl h-9">
            {value ? fmt.format(value) : <span className="text-neutral-400">{placeholder}</span>}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start" sideOffset={8}>
          <Calendar mode="single" selected={value} onSelect={onChange} initialFocus locale={es} />
        </PopoverContent>
      </Popover>
    </div>
  );
}

function DateRangePicker({
  label, value, onChange, months = 2, error,
}: { label: string; value: DateRange; onChange: (r: DateRange) => void; months?: number; error?: string; }) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <Label className="text-xs">{label}</Label>
        {error ? <span className="text-[11px] text-red-500">{error}</span> : null}
      </div>
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" className="w-full justify-start rounded-xl h-9">
            {fmtRange(value)}
          </Button>
        </PopoverTrigger>
        <PopoverContent align="start" side="bottom" sideOffset={8} className="w-auto p-0 min-w-[320px] sm:min-w-[620px]">
          <div className="p-2">
            <Calendar
              mode="range"
              numberOfMonths={months}
              selected={{ from: value?.from, to: value?.to } as any}
              onSelect={(val) => onChange({ from: val?.from, to: val?.to })}
              initialFocus
              defaultMonth={value?.from ?? new Date()}
              locale={es}
              classNames={{
                months: "flex flex-col sm:flex-row sm:items-start gap-3 sm:gap-4",
                month: "space-y-2",
                caption: "flex justify-center pt-2 relative items-center",
              }}
            />
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}

// ======= MAIN =======
export default function GroupsSection() {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<"create" | "edit">("create");
  const [selected, setSelected] = useState<CicloDTO | null>(null);

  // Toolbar
  const [q, setQ] = useState("");
  const [fIdioma, setFIdioma] = useState<string | undefined>();
  const [fModalidad, setFModalidad] = useState<string | undefined>();
  const [fTurno, setFTurno] = useState<string | undefined>();
  const [fNivel, setFNivel] = useState<string | undefined>();

  // Paginación & data
  const PAGE_SIZE = 8;
  const [page, setPage] = useState(1);
  const [data, setData] = useState<CicloListResponse | null>(null);
  const items = data?.items ?? [];
  const canPrev = (data?.page ?? 1) > 1;
  const canNext = !!data && data.page < data.pages;

  // Form
  const form = useForm<FormType>({
    resolver: zodResolver(FormSchema),
    defaultValues: EMPTY_FORM,
    mode: "onChange",
  });
  const {
    control, register, handleSubmit,
    formState: { errors, isSubmitting, isValid },
    reset, watch, setValue
  } = form;

  // Fetch lista
  async function fetchList(params: ListCiclosParams) {
    const resp = await listCiclos(params);
    setData(resp);
  }

  useEffect(() => {
    const params: ListCiclosParams = {
      page,
      page_size: PAGE_SIZE,
      q: q || undefined,
      idioma: fIdioma as any,
      modalidad: fModalidad as any,
      turno: fTurno as any,
      nivel: fNivel as any,
    };
    fetchList(params).catch((e) => {
      console.error(e);
      toast.error(e?.message || "No se pudo cargar la lista de ciclos");
    });
  }, [page, q, fIdioma, fModalidad, fTurno, fNivel]);

  const refreshFirstPage = async () => {
    await fetchList({ page: 1, page_size: PAGE_SIZE });
    setPage(1);
  };

  // Submit (create / edit)
  const onSubmit = async (values: FormType) => {
    const payload = {
      codigo: values.codigo.trim(),
      idioma: values.idioma,
      modalidad: values.modalidad,
      turno: values.turno,
      nivel: values.nivel,

      // 👇 NUEVOS CAMPOS AL PAYLOAD
      modalidad_asistencia: values.modalidad_asistencia,
      aula: values.aula?.trim() || undefined,

      cupo_total: values.cupo_total,

      dias: values.dias,                // 👈 horario
      hora_inicio: values.hora_inicio,  // 👈 horario
      hora_fin: values.hora_fin,        // 👈 horario

      inscripcion: rangeToISO(values.inscripcion)!,
      reinscripcion: rangeToISO(values.reinscripcion)!,
      curso: rangeToISO(values.curso)!,
      colocacion: rangeToISO(values.colocacion)!,
      examenMT: dateToISO(values.examenMT)!,
      examenFinal: dateToISO(values.examenFinal)!,
      notas: values.notas?.trim() || undefined,
    };

    try {
      if (mode === "create") {
        await createCiclo(payload);
        toast.success("Ciclo creado");
      } else {
        if (!selected) throw new Error("No hay ciclo seleccionado");
        await updateCiclo(selected.id, payload);
        toast.success("Ciclo actualizado");
      }

      setOpen(false);
      setSelected(null);
      setMode("create");
      reset(EMPTY_FORM, { keepDefaultValues: false });
      await refreshFirstPage();
    } catch (err: any) {
      console.error(err);
      toast.error(err?.message || (mode === "create" ? "No se pudo crear el ciclo" : "No se pudo actualizar el ciclo"));
    }
  };

  const onEdit = (c: CicloDTO) => {
    setMode("edit");
    setSelected(c);
    const diasFromDTO = ((c as any).dias ?? []) as string[];
    reset({
      codigo: c.codigo,
      idioma: c.idioma as any,
      modalidad: c.modalidad,
      turno: c.turno,
      nivel: (c as any).nivel as any,

      // 👇 NUEVOS CAMPOS DESDE DTO
      modalidad_asistencia: (c as any).modalidad_asistencia ?? "presencial",
      aula: (c as any).aula ?? "",

      cupo_total: (c as any).cupo_total ?? 0,

      dias: diasFromDTO,
      hora_inicio: (c as any).hora_inicio ?? "",
      hora_fin: (c as any).hora_fin ?? "",

      inscripcion: rangeFromDTO(c.inscripcion) as any,
      reinscripcion: rangeFromDTO(c.reinscripcion) as any,
      curso: rangeFromDTO(c.curso) as any,
      colocacion: rangeFromDTO(c.colocacion) as any,
      examenMT: isoToDate(c.examenMT)!,
      examenFinal: isoToDate(c.examenFinal)!,
      notas: c.notas ?? "",
    } as FormType);
    setOpen(true);
  };

  const onDelete = async (c: CicloDTO) => {
    try {
      await deleteCiclo(c.id);
      toast.success("Ciclo eliminado");
      await refreshFirstPage();
    } catch (err: any) {
      console.error(err);
      toast.error(err?.message || "No se pudo eliminar el ciclo");
    }
  };

  const openCreate = () => {
    setMode("create");
    setSelected(null);
    reset(EMPTY_FORM, { keepDefaultValues: false });
    setOpen(true);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-1">
          <h1 className="text-2xl font-semibold tracking-tight">
            <span className="bg-gradient-to-r from-neutral-900 to-neutral-500 bg-clip-text text-transparent">
              Grupos
            </span>
          </h1>
          <p className="text-sm text-neutral-600">
            Administra ciclos (grupos), idiomas, niveles, cupos, calendarios y horario.
          </p>
        </div>

        <Button className="gap-2 rounded-xl shadow-sm" onClick={openCreate}>
          <PlusCircle className="h-4 w-4" />
          Crear nuevo ciclo
        </Button>
      </header>

      {/* Toolbar */}
      <div className="rounded-2xl border bg-white/70 p-4 shadow-sm">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="relative w-full md:max-w-sm">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
            <Input
              value={q}
              onChange={(e) => { setQ(e.target.value); setPage(1); }}
              placeholder="Buscar ciclo por código…"
              className="pl-9 rounded-xl h-9"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="secondary" className="hidden md:inline-flex gap-1">
              <Filter className="h-3.5 w-3.5" /> Filtros
            </Badge>

            <Select value={fIdioma} onValueChange={(v) => { setFIdioma(v); setPage(1); }}>
              <SelectTrigger className="w-[140px] rounded-xl h-9">
                <SelectValue placeholder="Idioma" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ingles">Inglés</SelectItem>
                <SelectItem value="frances">Francés</SelectItem>
                <SelectItem value="aleman">Alemán</SelectItem>
                <SelectItem value="italiano">Italiano</SelectItem>
                <SelectItem value="portugues">Portugués</SelectItem>
              </SelectContent>
            </Select>

            <Select value={fModalidad} onValueChange={(v) => { setFModalidad(v); setPage(1); }}>
              <SelectTrigger className="w-[140px] rounded-xl h-9">
                <SelectValue placeholder="Modalidad" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="intensivo">Intensivo</SelectItem>
                <SelectItem value="sabatino">Sabatino</SelectItem>
                <SelectItem value="semestral">Semestral</SelectItem>
              </SelectContent>
            </Select>

            <Select value={fTurno} onValueChange={(v) => { setFTurno(v); setPage(1); }}>
              <SelectTrigger className="w-[140px] rounded-xl h-9">
                <SelectValue placeholder="Turno" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="matutino">Matutino</SelectItem>
                <SelectItem value="vespertino">Vespertino</SelectItem>
                <SelectItem value="mixto">Mixto</SelectItem>
              </SelectContent>
            </Select>

            <Select value={fNivel} onValueChange={(v) => { setFNivel(v); setPage(1); }}>
              <SelectTrigger className="w-[120px] rounded-xl h-9">
                <SelectValue placeholder="Nivel" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="A1">A1</SelectItem>
                <SelectItem value="A2">A2</SelectItem>
                <SelectItem value="B1">B1</SelectItem>
                <SelectItem value="B2">B2</SelectItem>
                <SelectItem value="C1">C1</SelectItem>
                <SelectItem value="C2">C2</SelectItem>
              </SelectContent>
            </Select>

            {(fIdioma || fModalidad || fTurno || fNivel || q) ? (
              <Button
                variant="outline"
                className="rounded-xl h-9"
                onClick={() => { setQ(""); setFIdioma(undefined); setFModalidad(undefined); setFTurno(undefined); setFNivel(undefined); setPage(1); }}
              >
                Limpiar
              </Button>
            ) : null}
          </div>
        </div>

        <Separator className="my-4" />

        {/* Lista + paginación */}
        {items.length ? (
          <>
            <div className="grid gap-3 sm:grid-cols-2">
              {items.map((c) => (
                <CardCiclo key={c.id} c={c} onEdit={onEdit} onDelete={onDelete} />
              ))}
            </div>

            <div className="mt-4 flex items-center justify-between">
              <span className="text-xs text-neutral-500">
                Página {data?.page} de {data?.pages} · {data?.total} resultados
              </span>
              <div className="flex gap-2">
                <Button variant="outline" size="icon" className="h-9 w-9 rounded-xl" disabled={!canPrev}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" className="h-9 w-9 rounded-xl" disabled={!canNext}
                  onClick={() => setPage((p) => (data ? Math.min(data.pages, p + 1) : p + 1))}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="rounded-2xl border bg-white/70 p-6 text-sm text-neutral-600">
            {q || fIdioma || fModalidad || fTurno || fNivel ? "No hay ciclos que coincidan con los filtros." : "No hay ciclos configurados."}
          </div>
        )}
      </div>

      {/* Dialog Crear/Editar */}
      <Dialog
        open={open}
        onOpenChange={(v) => {
          setOpen(v);
          if (!v) {
            setMode("create");
            setSelected(null);
            reset(EMPTY_FORM, { keepDefaultValues: false });
          }
        }}
      >
        <DialogContent
          key={`${mode}-${selected?.id ?? "new"}`} // fuerza remount para limpiar pickers/selects
        className="w-full sm:max-w-5xl p-0 overflow-hidden rounded-2xl border bg-white/90 shadow-2xl backdrop-blur"
        >
          <DialogHeader className="sticky top-0 z-10 bg-white/70 backdrop-blur px-6 py-4 border-b">
            <DialogTitle className="text-lg font-semibold">
              {mode === "create" ? "Crear nuevo ciclo" : `Editar ciclo: ${selected?.codigo}`}
            </DialogTitle>
            <DialogDescription className="text-neutral-600">
              Fechas en formato <b>periodo</b> y horario por días.
            </DialogDescription>
          </DialogHeader>

          <FormCiclo
            onSubmit={handleSubmit(onSubmit)}
            errors={errors}
            control={control}
            register={register}
            isSubmitting={isSubmitting}
            isValid={isValid}
            setValue={setValue}      // 👈 pasamos setValue
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ======= Subcomponentes ======= */

function CardCiclo({ c, onEdit, onDelete }: {
  c: CicloDTO;
  onEdit: (c: CicloDTO) => void;
  onDelete: (c: CicloDTO) => void;
}) {
  const cupo = (c as any).cupo_total ?? 0;
  const nivel = (c as any).nivel as string | undefined;
  const dias = ((c as any).dias ?? []) as string[];
  const hInicio = (c as any).hora_inicio as string | undefined;
  const hFin = (c as any).hora_fin as string | undefined;
  //const d = (s: string) => fmtShort.format(new Date(s));
  
  const d = (s?: string) => {
  if (!s) return "—";
  const dt = new Date(`${s}T00:00:00`);
  const day = dt.toLocaleString("es-MX", { day: "2-digit" });
  const month = dt.toLocaleString("es-MX", { month: "short" }); // "ago"
  const year = dt.toLocaleString("es-MX", { year: "2-digit" }); // "25"
  return `${day}/${month}/${year}`; // "27/ago/25"
};

  const diasTexto = dias.length ? dias.map(d => abreviarDia(d)).join(" • ") : "—";
  const horarioTexto = hInicio && hFin ? `${hInicio}–${hFin}` : "—";

  // 👇 nuevos campos
  const modalidadAsistencia = (c as any).modalidad_asistencia as "presencial" | "virtual" | undefined;
  const aula = (c as any).aula as string | undefined;

  return (
    <div className="rounded-xl border bg-white/60 p-4 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between gap-2">
        <div className="w-full">
          <h3 className="font-medium">{c.codigo}</h3>

          {/* Badges */}
          <div className="mt-1 flex flex-wrap gap-1.5 items-center">
            <Badge variant="secondary" className="rounded-full">{c.idioma}</Badge>
            <Badge variant="secondary" className="rounded-full">{c.modalidad}</Badge>
            <Badge variant="outline" className="rounded-full">{c.turno}</Badge>
            {nivel ? (
              <span className="ml-1 inline-flex items-center gap-1 text-xs text-neutral-700">
                <GraduationCap className="h-3.5 w-3.5" /> {nivel}
              </span>
            ) : null}
            <span className="ml-2 inline-flex items-center gap-1 text-xs text-neutral-700">
              <Users className="h-3.5 w-3.5" /> {cupo} lugares
            </span>

            {/* 👇 muestra modalidad_asistencia y aula */}
            {modalidadAsistencia ? (
              <Badge variant="secondary" className="rounded-full capitalize">
                {modalidadAsistencia}
              </Badge>
            ) : null}
            {aula ? (
              <span className="ml-1 inline-flex items-center gap-1 text-xs text-neutral-700">
                <Building2 className="h-3.5 w-3.5" /> {aula}
              </span>
            ) : null}
          </div>

          {/* Horario */}
          <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-y-1 text-xs text-neutral-700">
            <div className="inline-flex items-center gap-1">
              <CalendarDays className="h-3.5 w-3.5" />
              <b>Días:</b>&nbsp;{diasTexto}
            </div>
            <div className="inline-flex items-center gap-1">
              <Clock3 className="h-3.5 w-3.5" />
              <b>Horario:</b>&nbsp;{horarioTexto}
            </div>
          </div>

          {/* Detalles del calendario */}
          <dl className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5 text-[11.5px] text-neutral-700">
            <div className="flex gap-1">
              <dt className="min-w-[92px] font-medium text-neutral-800">Curso:</dt>
              <dd className="tabular-nums">{d(c.curso.from)} – {d(c.curso.to)}</dd>
            </div>
            <div className="flex gap-1">
              <dt className="min-w-[92px] font-medium text-neutral-800">Colocación:</dt>
              <dd className="tabular-nums">{d(c.colocacion.from)} – {d(c.colocacion.to)}</dd>
            </div>
            <div className="flex gap-1">
              <dt className="min-w-[92px] font-medium text-neutral-800">Inscripción:</dt>
              <dd className="tabular-nums">{d(c.inscripcion.from)} – {d(c.inscripcion.to)}</dd>
            </div>
            <div className="flex gap-1">
              <dt className="min-w-[92px] font-medium text-neutral-800">Reinscripción:</dt>
              <dd className="tabular-nums">{d(c.reinscripcion.from)} – {d(c.reinscripcion.to)}</dd>
            </div>
            <div className="flex gap-1">
              <dt className="min-w-[92px] font-medium text-neutral-800">Examen MT:</dt>
              <dd className="tabular-nums">{d(c.examenMT)}</dd>
            </div>
            <div className="flex gap-1">
              <dt className="min-w-[92px] font-medium text-neutral-800">Examen final:</dt>
              <dd className="tabular-nums">{d(c.examenFinal)}</dd>
            </div>
          </dl>


          {c.notas ? (
            <p className="mt-2 text-xs text-neutral-700 italic">
              <b>Notas:</b> {c.notas}
            </p>
          ) : null}
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Acciones</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onEdit(c)}>
              <Pencil className="mr-2 h-4 w-4" /> Editar
            </DropdownMenuItem>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <DropdownMenuItem className="text-red-600">
                  <Trash2 className="mr-2 h-4 w-4" /> Eliminar
                </DropdownMenuItem>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Eliminar ciclo</AlertDialogTitle>
                  <AlertDialogDescription>
                    ¿Seguro que deseas eliminar <b>{c.codigo}</b>? Esta acción no se puede deshacer.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction
                    className="bg-red-600 hover:bg-red-700"
                    onClick={() => onDelete(c)}
                  >
                    Sí, eliminar
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

function FormCiclo({
  onSubmit, errors, control, register, isSubmitting, isValid, setValue,
}: any) {
  // 👇 Inteligencia de modalidad -> preselección de días
  const modalidad: "intensivo" | "sabatino" | "semestral" | undefined = useWatch({ control, name: "modalidad" });
  const modalidadAsistencia: "presencial" | "virtual" | undefined = useWatch({ control, name: "modalidad_asistencia" }); // 👈 nuevo watch
  const mountedRef = useRef(false);
  const prevModalidadRef = useRef<typeof modalidad>(undefined);

  useEffect(() => {
    // Evitar que al abrir en modo edición sobreescriba los días existentes.
    if (!mountedRef.current) {
      mountedRef.current = true;
      prevModalidadRef.current = modalidad;
      return;
    }
    if (prevModalidadRef.current === modalidad) return;
    prevModalidadRef.current = modalidad;

    if (modalidad === "intensivo") {
      setValue("dias", ["lunes", "martes", "miercoles", "jueves", "viernes"], { shouldValidate: true, shouldDirty: true });
    } else if (modalidad === "sabatino") {
      setValue("dias", ["sabado"], { shouldValidate: true, shouldDirty: true });
    }
    // modalidad "semestral" no fuerza nada
  }, [modalidad, setValue]);

  return (
    <form onSubmit={onSubmit}>
      <div className="px-6 py-5 space-y-5 max-h-[75vh] overflow-y-auto">
        {/* Datos generales */}
        <Section title="Datos generales">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            <div className="space-y-1.5 md:col-span-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Código</Label>
                {errors.codigo && <span className="text-[11px] text-red-500">{errors.codigo.message}</span>}
              </div>
              <Input placeholder="Ej: ING-A1-G25" className="h-9" {...register("codigo")} />
            </div>

            <div className="space-y-1.5 md:col-span-1">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Idioma</Label>
                {errors.idioma && <span className="text-[11px] text-red-500">{errors.idioma.message}</span>}
              </div>
              <Controller
                control={control}
                name="idioma"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger className="rounded-xl h-9">
                      <SelectValue placeholder="Seleccionar" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ingles">Inglés</SelectItem>
                      <SelectItem value="frances">Francés</SelectItem>
                      <SelectItem value="aleman">Alemán</SelectItem>
                      <SelectItem value="italiano">Italiano</SelectItem>
                      <SelectItem value="portugues">Portugués</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              />
            </div>

            <div className="space-y-1.5 md:col-span-1">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Modalidad</Label>
                {errors.modalidad && <span className="text-[11px] text-red-500">{errors.modalidad.message}</span>}
              </div>
              <Controller
                control={control}
                name="modalidad"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger className="rounded-xl h-9">
                      <SelectValue placeholder="Seleccionar" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="intensivo">Intensivo</SelectItem>
                      <SelectItem value="sabatino">Sabatino</SelectItem>
                      <SelectItem value="semestral">Semestral</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              />
            </div>

            <div className="space-y-1.5 md:col-span-1">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Turno</Label>
                {errors.turno && <span className="text-[11px] text-red-500">{errors.turno.message}</span>}
              </div>
              <Controller
                control={control}
                name="turno"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger className="rounded-xl h-9">
                      <SelectValue placeholder="Seleccionar" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="matutino">Matutino</SelectItem>
                      <SelectItem value="vespertino">Vespertino</SelectItem>
                      <SelectItem value="mixto">Mixto</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            <div className="space-y-1.5 md:col-span-1">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Nivel</Label>
                {errors.nivel && <span className="text-[11px] text-red-500">{errors.nivel.message}</span>}
              </div>
              <Controller
                control={control}
                name="nivel"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger className="rounded-xl h-9">
                      <SelectValue placeholder="Seleccionar" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A1">A1</SelectItem>
                      <SelectItem value="A2">A2</SelectItem>
                      <SelectItem value="B1">B1</SelectItem>
                      <SelectItem value="B2">B2</SelectItem>
                      <SelectItem value="C1">C1</SelectItem>
                      <SelectItem value="C2">C2</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              />
            </div>

            <div className="space-y-1.5 md:col-span-1">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Cupo (lugares)</Label>
                {errors.cupo_total && <span className="text-[11px] text-red-500">{errors.cupo_total.message}</span>}
              </div>
              <Input
                type="number"
                min={0}
                step={1}
                className="h-9"
                placeholder="0"
                {...register("cupo_total", { valueAsNumber: true })}
              />
            </div>
          </div>

          {/* 👇 NUEVA FILA: Modalidad de asistencia + Aula (condicional) */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            <div className="space-y-1.5 md:col-span-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Modalidad de asistencia</Label>
                {/* no error aquí: required ya lo maneja el select */}
              </div>
              <Controller
                control={control}
                name="modalidad_asistencia"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger className="rounded-xl h-9">
                      <SelectValue placeholder="Seleccionar" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="presencial">Presencial</SelectItem>
                      <SelectItem value="virtual">Virtual</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              />
            </div>

            {modalidadAsistencia === "presencial" && (
              <div className="space-y-1.5 md:col-span-2">
                <div className="flex items-center justify-between">
                  <Label className="text-xs">Aula</Label>
                  {errors.aula && <span className="text-[11px] text-red-500">{errors.aula.message}</span>}
                </div>
                <Input className="h-9" placeholder="Ej: 301-B"
                  {...register("aula")}
                />
              </div>
            )}
          </div>
        </Section>

        {/* Horario */}
        <Section title="Horario del grupo">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Días */}
            <div className="space-y-2">
              <Label className="text-xs">Días</Label>
              <div className="grid grid-cols-3 gap-2">
                {DIAS_OPCIONES.map(({ key, label }) => (
                  <Controller
                    key={key}
                    control={control}
                    name="dias"
                    render={({ field }) => {
                      const checked = (field.value as string[]).includes(key);
                      return (
                        <label className="flex items-center gap-2 rounded-lg border px-2 py-1.5">
                          <Checkbox
                            checked={checked}
                            onCheckedChange={(v) => {
                              const arr = new Set(field.value as string[]);
                              if (v) arr.add(key); else arr.delete(key);
                              field.onChange(Array.from(arr));
                            }}
                          />
                          <span className="text-sm">{label}</span>
                        </label>
                      );
                    }}
                  />
                ))}
              </div>
              {errors.dias && <span className="text-[11px] text-red-500">{errors.dias.message as string}</span>}
            </div>

            {/* Horas */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label className="text-xs">Hora inicio</Label>
                  {errors.hora_inicio && <span className="text-[11px] text-red-500">{errors.hora_inicio.message as string}</span>}
                </div>
                <Controller
                  control={control}
                  name="hora_inicio"
                  render={({ field }) => (
                    <Select value={field.value} onValueChange={field.onChange}>
                      <SelectTrigger className="rounded-xl h-9">
                        <SelectValue placeholder="HH:MM" />
                      </SelectTrigger>
                      <SelectContent className="max-h-72">
                        {horasValidas.map(h => (
                          <SelectItem key={h} value={h}>{h}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label className="text-xs">Hora fin</Label>
                  {errors.hora_fin && <span className="text-[11px] text-red-500">{errors.hora_fin.message as string}</span>}
                </div>
                <Controller
                  control={control}
                  name="hora_fin"
                  render={({ field }) => (
                    <Select value={field.value} onValueChange={field.onChange}>
                      <SelectTrigger className="rounded-xl h-9">
                        <SelectValue placeholder="HH:MM" />
                      </SelectTrigger>
                      <SelectContent className="max-h-72">
                        {horasValidas.map(h => (
                          <SelectItem key={h} value={h}>{h}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                />
              </div>
            </div>
          </div>
        </Section>

        {/* Periodo del curso */}
        <Section title="Periodo del curso">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Controller
              control={control}
              name="curso"
              render={({ field }) => (
                <DateRangePicker
                  label=""
                  value={field.value as DateRange}
                  onChange={field.onChange}
                  months={2}
                  error={errors.curso?.to?.message || errors.curso?.from?.message}
                />
              )}
            />
          </div>
        </Section>

        {/* Inscripción y reinscripción */}
        <Section title="Inscripción y reinscripción">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Controller
              control={control}
              name="inscripcion"
              render={({ field }) => (
                <DateRangePicker
                  label="Periodo de inscripción"
                  value={field.value as DateRange}
                  onChange={field.onChange}
                  months={2}
                  error={errors.inscripcion?.to?.message || errors.inscripcion?.from?.message}
                />
              )}
            />
            <Controller
              control={control}
              name="reinscripcion"
              render={({ field }) => (
                <DateRangePicker
                  label="Periodo de reinscripción"
                  value={field.value as DateRange}
                  onChange={field.onChange}
                  months={2}
                  error={errors.reinscripcion?.to?.message || errors.reinscripcion?.from?.message}
                />
              )}
            />
          </div>
        </Section>

        {/* Exámenes */}
        <Section title="Exámenes">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Controller
              control={control}
              name="colocacion"
              render={({ field }) => (
                <DateRangePicker
                  label="Colocación (periodo)"
                  value={field.value as DateRange}
                  onChange={field.onChange}
                  months={2}
                  error={errors.colocacion?.to?.message || errors.colocacion?.from?.message}
                />
              )}
            />
            <Controller
              control={control}
              name="examenMT"
              render={({ field }) => (
                <DatePicker
                  label="Examen MT (fecha única)"
                  value={field.value as Date}
                  onChange={field.onChange}
                  error={errors.examenMT?.message}
                />
              )}
            />
            <Controller
              control={control}
              name="examenFinal"
              render={({ field }) => (
                <DatePicker
                  label="Examen final (fecha única)"
                  value={field.value as Date}
                  onChange={field.onChange}
                  error={errors.examenFinal?.message}
                />
              )}
            />
          </div>
        </Section>

        <Section title="Avisos">
          <div className="grid grid-cols-1 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">Notas</Label>
              <Textarea rows={3} placeholder="Notas o avisos importantes…" className="rounded-xl" {...(register("notas"))} />
            </div>
          </div>
        </Section>
      </div>

      <Separator />
      <DialogFooter className="sticky bottom-0 bg-white/70 backdrop-blur px-6 py-3">
        {/* Cierra el modal y dispara onOpenChange (que resetea) */}
        <DialogClose asChild>
          <Button type="button" variant="outline" className="rounded-xl h-9">
            Cancelar
          </Button>
        </DialogClose>
        <Button type="submit" disabled={!isValid || isSubmitting} className="rounded-xl h-9">
          {isSubmitting ? "Guardando…" : "Guardar"}
        </Button>
      </DialogFooter>
    </form>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode; }) {
  return (
    <section className="rounded-2xl border bg-white/60 p-4 shadow-sm">
      <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-neutral-700">{title}</h3>
      {children}
    </section>
  );
}

// util local
function abreviarDia(key: string) {
  const m: Record<string, string> = {
    lunes: "Lun",
    martes: "Mar",
    miercoles: "Mié",
    jueves: "Jue",
    viernes: "Vie",
    sabado: "Sáb",
    domingo: "Dom",
  };
  return m[key] ?? key;
}
